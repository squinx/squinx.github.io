// edit record scripts
jQuery(document).ready( function($) {
		$( ".edit-participant input.date_field" ).datepicker();
});